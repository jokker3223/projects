$(document).ready(function(){
    ScrollReveal().reveal('.contact-form', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.carousel', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.pricing1', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.pricing2', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.post-1', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.post-2', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.post-3', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.benefit-1', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.benefit-2', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.benefit-3', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.desc-img', {
        distance: '50px',
        origin: 'right',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.desc-text', {
        distance: '50px',
        origin: 'left',
        duration: 500,
        reset: true
    });
    ScrollReveal().reveal('.desc-img2', {
        distance: '50px',
        origin: 'right',
        duration: 1000,
        reset: true
    });
    ScrollReveal().reveal('.desc-text2', {
        distance: '50px',
        origin: 'left',
        duration: 500,
        reset: true
    });
    ScrollReveal().reveal('.sd1', {
        distance: '50px',
        origin: 'bottom',
        duration: 500,
        delay: 200,
        reset: true
    });
    ScrollReveal().reveal('.sd2', {
        distance: '50px',
        origin: 'bottom',
        duration: 500,
        delay: 400,
        reset: true
    });
    ScrollReveal().reveal('.sd3', {
        distance: '50px',
        origin: 'bottom',
        duration: 500,
        delay: 600,
        reset: true
    });
    ScrollReveal().reveal('.sd4', {
        distance: '50px',
        origin: 'bottom',
        duration: 1000,
        delay: 800,
        reset: true
    });
});