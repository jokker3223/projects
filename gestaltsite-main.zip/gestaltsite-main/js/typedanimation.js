var typed = new Typed('#typetext', {
    strings: ["Excellence.", "Solutions.", "Brilliance.", "Innovation.", "Mastery.", "Impact.", "Perfection.", "Magic.", "Power.", "Creativity."],
    typeSpeed: 50,
    fadeOut: true,
    fadeOutClass: 'typed-fade-out',
    startDelay: 1000,
    loop:true
  });